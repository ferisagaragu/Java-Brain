(function ($) {
    "use strict"; // Start of use strict

    makeTable('util');
    makeTable('swing');
    
    onKey('util');
    onKey('swing');
    
})(jQuery); // End of use strict

